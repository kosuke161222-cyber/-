const CACHE="aikatsu-encore-v1";
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(["./aikatsu_encore_card_manager.html","./manifest.webmanifest","./icon-192.png","./icon-512.png"]))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
